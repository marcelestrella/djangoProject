from django.shortcuts import render
from django.views.generic.edit import UpdateView 
from django.urls import reverse_lazy, reverse
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import Libro 
from .forms import LibroForm 
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from apps.users.helpers import *
from django.db.models import Q


class LibroUpdateView(StaffRequiredMixin, UpdateView): 
	# specify the model you want to use 
	model = Libro 
	template_name = "actualizar_libro.html"
	# specify the fields 
	fields = [ 
		"titulo", 
		"autor",
		"ano_edicion",
		"tematica",
		"isbn",
		"editorial",
		"ano_editorial",
		"descripcion"
	] 

	success_url ="/"
	login_url= reverse_lazy('users_app:user-login')
     
@login_required(login_url='/login/')

def create_view(request): 
    context ={} 

    form = LibroForm(request.POST or None) 
    if form.is_valid(): 
        form.save() 

    context['form']= form 
    return render(request, "agregar_libro.html", context)

def list_view(request):
    context ={}
 
    # add the dictionary during initialization
    context["dataset"] = Libro.objects.all()
         
    return render(request, "lista_libro.html", context)



def list_view(request):
    context = {}

    if 'query' in request.GET:
        query = request.GET.get('query')
        libros = Libro.objects.filter(
            Q(titulo__icontains=query) |
            Q(autor__name__icontains=query) |
            Q(tematica__nombre__icontains=query) |
            Q(isbn__icontains=query)
        )
        context['query'] = query
        context['dataset'] = libros
    else:
        context['dataset'] = Libro.objects.all()

    return render(request, "lista_libro.html", context)



