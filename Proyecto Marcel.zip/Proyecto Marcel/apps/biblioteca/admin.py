from django.contrib import admin
from .models import Autor, Editorial, Tematica, Libro

admin.site.register(Autor)
admin.site.register(Editorial)
admin.site.register(Tematica)

@admin.register(Libro)
class LibroAdmin(admin.ModelAdmin):
    list_display = ('titulo', 'autor', 'ano_edicion', 'tematica', 'isbn', 'editorial', 'ano_editorial')
    search_fields = ('titulo', 'autor__nombre', 'autor__apellido', 'isbn')
    list_filter = ('ano_edicion', 'tematica', 'ano_editorial', 'editorial')
    ordering = ('ano_edicion',)

