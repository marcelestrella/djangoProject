from django.urls import path

from .views import *

app_name = 'blog_app'

urlpatterns = [
    path('blog', ListPosts.as_view(), name="list-posts"),
]